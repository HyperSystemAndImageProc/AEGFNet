import torch
import torch.nn as nn
import torch.nn.functional as F
from thop import profile
import numpy as np
import math
import warnings
import numpy as np
from functools import partial


class Pyramid_Extraction(nn.Module):
    def __init__(self,channel, rate=1, bn_mom=0.1):
        super(Pyramid_Extraction, self).__init__()
        self.channel=channel

        self.branch1 = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=(3, 3), stride=(1, 1), padding=rate, dilation=rate, groups=channel,
                      bias=True),
            nn.BatchNorm2d(channel, momentum=bn_mom),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel, channel , kernel_size=(1, 1), stride=(1, 1), padding=0, bias=True),
            nn.BatchNorm2d(channel , momentum=bn_mom),
            nn.ReLU(inplace=True),
        )

        self.branch2 = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=(3, 3), stride=(1, 1), padding=1, groups=channel, bias=False),
            nn.BatchNorm2d(channel, momentum=bn_mom),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel, channel, kernel_size=(1, 1), stride=(1, 1), padding=0, bias=False),
            nn.BatchNorm2d(channel , momentum=bn_mom),
            nn.ReLU(inplace=True),
        )



        self.branch3 = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=(3, 3), stride=(1, 1), padding=4 * rate, dilation=4 * rate,
                      groups=channel, bias=False),
            nn.BatchNorm2d(channel, momentum=bn_mom),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel, channel, kernel_size=(1, 1), stride=(1, 1), padding=0, bias=False),
            nn.BatchNorm2d(channel , momentum=bn_mom),
            nn.ReLU(inplace=True),
        )



        self.branch4 = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=(3, 3), stride=(1, 1), padding=8 * rate, dilation=8 * rate,
                      groups=channel, bias=False),
            nn.BatchNorm2d(channel, momentum=bn_mom),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel, channel , kernel_size=(1, 1), stride=(1, 1), padding=0, bias=False),
            nn.BatchNorm2d(channel , momentum=bn_mom),
            nn.ReLU(inplace=True),
        )

        self.branch5_conv = nn.Conv2d(channel, channel, kernel_size=(1, 1), stride=(1, 1), padding=0, bias=True)
        self.branch5_bn = nn.BatchNorm2d(channel, momentum=bn_mom)
        self.branch5_relu = nn.ReLU(inplace=True)


        self.conv_cat = nn.Sequential(
            nn.Conv2d((channel ) * 5, (channel ) * 5, kernel_size=(1, 1), stride=(1, 1), padding=0,
                      groups=(channel ) * 5, bias=False),
            nn.BatchNorm2d((channel ) * 5, momentum=bn_mom),
            nn.ReLU(inplace=True),
            nn.Conv2d((channel ) * 5, channel, kernel_size=(1, 1), stride=(1, 1), padding=0, bias=False),
            nn.BatchNorm2d(channel, momentum=bn_mom),
            nn.ReLU(inplace=True),
        )

    def forward(self,x):
        [b,c,row,col]=x.size()

        conv1_1=self.branch1(x)
        #print(conv1_1.size())
        conv3_1=self.branch2(x)
        conv3_2=self.branch3(x)
        conv3_3=self.branch4(x)

        global_feature = torch.mean(x, 2, True)
        global_feature = torch.mean(global_feature, 3, True)
        global_feature = self.branch5_conv(global_feature)
        global_feature = self.branch5_bn(global_feature)
        global_feature = self.branch5_relu(global_feature)
        global_feature = F.interpolate(global_feature, (row, col), None, 'bilinear', True)

        # 五个分支的内容堆叠起来，然后1x1卷积整合特征。
        feature_cat = torch.cat([conv1_1, conv3_1, conv3_2, conv3_3, global_feature], dim=1)
        result = self.conv_cat(feature_cat)
        return result

class Pyramid_Merge(nn.Module):
    def __init__(self,channel):
        super(Pyramid_Merge, self).__init__()
        self.channel=channel
        self.cbam=CBAM(channel)
        self.pe=Pyramid_Extraction(channel)
        # self.conv=nn.Sequential(
        #     nn.Conv2d(channel*2,channel,kernel_size=1,stride=1),
        # )


        self.conv = nn.Sequential(
            nn.Conv2d(channel*2, channel*2, kernel_size=1, groups=channel*2),
            nn.BatchNorm2d(channel*2),
            nn.ReLU(),
            nn.Conv2d(channel*2, channel, kernel_size=1),
            nn.BatchNorm2d(channel),
            nn.ReLU()
        )

    def forward(self,input1,input2):

        input_cat=torch.cat([input1,input2],dim=1)
        input_abs=torch.abs(input1-input2)

        #print(input_cat.size(),input_abs.size())
        input_cat_conv=self.conv(input_cat)
        #print(input_cat_conv.size())
        input_cat_conv_cbam=self.cbam(input_cat_conv)
        #print(input_cat_conv_cbam.size())
        # input_cat_cbam=self.cbam(input_cat)
        #input_cat_cbam_conv=self.conv(input_cat_cbam)

        input_abs_py=self.pe(input_abs)
        #print(input_abs_py.size())

        input_abs_py_abs=input_abs_py+input_abs

        out1=input_abs_py_abs+input_cat_conv_cbam

        return out1

class Doubleconv(nn.Module):
    def __init__(self, input_channels, num_channels,):
        super().__init__()
        # self.conv1 = nn.Conv2d(input_channels, num_channels,
        #                        kernel_size=3, padding=1, stride=strides),
        # self.conv1=nn.Sequential(
        #     nn.Conv2d(input_channels, num_channels,kernel_size=3, padding=1, stride=strides),
        #     nn.BatchNorm2d(num_channels),
        #     nn.ReLU()
        #
        # )
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_channels, input_channels, kernel_size=3, padding=1, groups=input_channels),
            nn.BatchNorm2d(input_channels),
            nn.ReLU(),
            nn.Conv2d(input_channels, num_channels, kernel_size=1),
            nn.BatchNorm2d(num_channels),
            nn.ReLU()
        )

        # self.conv2 = nn.Conv2d(num_channels, num_channels,
        #                        kernel_size=3, padding=1)

        self.conv2 = nn.Sequential(
            nn.Conv2d(num_channels, num_channels, kernel_size=3, padding=1, groups=num_channels),
            nn.BatchNorm2d(num_channels),
            nn.ReLU(),
            nn.Conv2d(num_channels, num_channels, kernel_size=1),
            nn.BatchNorm2d(num_channels),
            nn.ReLU()
        )

    def forward(self, X):
        Y = self.conv1(X)
        Y = self.conv2(Y)
        return Y

class Edge_Aware_1(nn.Module):
    def __init__(self,channel1,channel2):
        super(Edge_Aware_1, self).__init__()
        # self.conv_channel1=nn.Sequential(
        #     nn.Conv2d(channel1,channel1//4,kernel_size=1),
        #     nn.BatchNorm2d(channel1//4),
        #     nn.ReLU
        # )
        self.conv_channel1 = nn.Sequential(
            nn.Conv2d(channel1, channel1, kernel_size=3, padding=1, groups=channel1),
            nn.BatchNorm2d(channel1),
            nn.ReLU(),
            nn.Conv2d(channel1, channel1, kernel_size=1),
            nn.BatchNorm2d(channel1 ),
            nn.ReLU()
        )
        self.conv_channel2 = nn.Sequential(
            nn.Conv2d(channel2, channel2, kernel_size=3, padding=1, groups=channel2),
            nn.BatchNorm2d(channel2),
            nn.ReLU(),
            nn.Conv2d(channel2, channel2, kernel_size=1),
            nn.BatchNorm2d(channel2 ),
            nn.ReLU()
        )

        self.doubleconv=Doubleconv(channel1 +channel2,(channel1 +channel2)*2)
        self.conv1=nn.Sequential(
            nn.Conv2d((channel1 +channel2)*2,2,kernel_size=1),
            nn.BatchNorm2d(2),
            #nn.Sigmoid()
        )
        self.sef = Semantic_flow(512, 64)

    def forward(self,input1,input4):
        #print(input1.size(),input4.size())
        input1=self.conv_channel1(input1)
        input4=self.conv_channel2(input4)
        #print(input1.size(),input4.size())
        input4_sef=self.sef(input4,input1)
        input4_big=F.interpolate(input4, size=input1.size()[2:], mode='bilinear', align_corners=False)+input4_sef
        input=torch.cat([input4_big,input1],dim=1)
        input_res=self.doubleconv(input)
        out=self.conv1(input_res)
        return out
class Edge_Aware_0(nn.Module):
    def __init__(self,channel1,channel2):
        super(Edge_Aware_0, self).__init__()
        # self.conv_channel1=nn.Sequential(
        #     nn.Conv2d(channel1,channel1//4,kernel_size=1),
        #     nn.BatchNorm2d(channel1//4),
        #     nn.ReLU
        # )
        self.conv_channel1 = nn.Sequential(
            nn.Conv2d(channel1, channel1, kernel_size=3, padding=1, groups=channel1),
            nn.BatchNorm2d(channel1),
            nn.ReLU(),
            nn.Conv2d(channel1, channel1 , kernel_size=1),
            nn.BatchNorm2d(channel1 ),
            nn.ReLU()
        )
        self.conv_channel2 = nn.Sequential(
            nn.Conv2d(channel2, channel2, kernel_size=3, padding=1, groups=channel2),
            nn.BatchNorm2d(channel2),
            nn.ReLU(),
            nn.Conv2d(channel2, channel2, kernel_size=1),
            nn.BatchNorm2d(channel2 ),
            nn.ReLU()
        )

        self.doubleconv=Doubleconv(channel1 +channel2,(channel1 +channel2)*2)
        self.conv1=nn.Sequential(
            nn.Conv2d((channel1 +channel2)*2,2,kernel_size=1),
            nn.BatchNorm2d(2),
            #nn.Sigmoid()
        )

        self.sef = Semantic_flow(256, 32)

    def forward(self,input1,input4):
        input1=self.conv_channel1(input1)
        input4=self.conv_channel2(input4)
        #print(input1.size(),input4.size())
        input4_sef=self.sef(input4,input1)
        input4_big=F.interpolate(input4, size=input1.size()[2:], mode='bilinear', align_corners=False)+input4_sef
        #print(input4_big.size())
        input=torch.cat([input4_big,input1],dim=1)
        input_res=self.doubleconv(input)
        out=self.conv1(input_res)
        return out

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)  # 7,3     3,1
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class CBAM(nn.Module):
    def __init__(self, in_planes, ratio=16, kernel_size=7):
        super(CBAM, self).__init__()
        self.ca = ChannelAttention(in_planes, ratio)
        self.sa = SpatialAttention(kernel_size)

    def forward(self, x):
        out = x * self.ca(x)
        result = out * self.sa(out)
        return result

class Edge_Guidance_1(nn.Module):
    def __init__(self):
        super(Edge_Guidance_1, self).__init__()

        self.maxpool1 = nn.MaxPool2d(2, stride=2)
        self.maxpool2 = nn.MaxPool2d(2, stride=2)
        self.maxpool3 = nn.MaxPool2d(2, stride=2)

        self.ea=Edge_Aware_1(64,512)
        self.conv2_1=nn.Sequential(
            nn.Conv2d(2,1,kernel_size=1),
            nn.BatchNorm2d(1),
            nn.Sigmoid()
        )
        self.ca1=CBAM(64)
        self.ca2=CBAM(128)
        self.ca3 = CBAM(320)
        self.ca4 = CBAM(512)

    def forward(self,input):
        input1,input2,input3,input4=input
        edge_64_2=self.ea(input1,input4)
        edge_64=self.conv2_1(edge_64_2)
        #print(edge_64_1.size())
        edge_32=self.maxpool1(edge_64)
        edge_16=self.maxpool2(edge_32)
        edge_8=self.maxpool3(edge_16)


        feature_1=input1*edge_64+input1
        feature_2=input2*edge_32+input2
        feature_3=input3*edge_16+input3
        feature_4=input4*edge_8+input4
        #print(feature_1.size(),feature_2.size(),feature_3.size(),feature_4.size())

        feature_1=self.ca1(feature_1)
        feature_2 = self.ca2(feature_2)
        feature_3 = self.ca3(feature_3)
        feature_4 = self.ca4(feature_4)

        return edge_64_2,feature_1,feature_2,feature_3,feature_4

class Edge_Guidance_0(nn.Module):
    def __init__(self):
        super(Edge_Guidance_0, self).__init__()

        self.maxpool1 = nn.MaxPool2d(2, stride=2)
        self.maxpool2 = nn.MaxPool2d(2, stride=2)
        self.maxpool3 = nn.MaxPool2d(2, stride=2)
        self.ea=Edge_Aware_0(32,256)
        self.conv2_1=nn.Sequential(
            nn.Conv2d(2,1,kernel_size=1),
            nn.BatchNorm2d(1),
            nn.Sigmoid()
        )
        self.ca1=CBAM(32)
        self.ca2=CBAM(64)
        self.ca3 = CBAM(160)
        self.ca4 = CBAM(256)

    def forward(self,input):
        input1,input2,input3,input4=input
        edge_64_2=self.ea(input1,input4)
        edge_64=self.conv2_1(edge_64_2)
        #print(edge_64_1.size())
        edge_32=self.maxpool1(edge_64)
        edge_16=self.maxpool2(edge_32)
        edge_8=self.maxpool3(edge_16)

        feature_1=input1*edge_64+input1
        feature_2=input2*edge_32+input2
        feature_3=input3*edge_16+input3
        feature_4=input4*edge_8+input4

        feature_1=self.ca1(feature_1)
        feature_2 = self.ca2(feature_2)
        feature_3 = self.ca3(feature_3)
        feature_4 = self.ca4(feature_4)

        return edge_64_2,feature_1,feature_2,feature_3,feature_4

class Resampler(nn.Module):
    def __init__(self, input_size, output_size):
        super(Resampler, self).__init__()
        self.input_size = input_size
        self.output_size = output_size

        grid_x, grid_y = torch.meshgrid(torch.linspace(-1, 1, output_size), torch.linspace(-1, 1, output_size), indexing='ij')
        self.grid = torch.stack((grid_y, grid_x), 2).unsqueeze(0)

    def forward(self, input_tensor):
        grid = self.grid.repeat(input_tensor.size(0), 1, 1, 1).to(input_tensor.device)
        output_tensor = F.grid_sample(input_tensor, grid, align_corners=True)
        return output_tensor

class Semantic_flow(nn.Module):
    def __init__(self,inchannel,outchannel):
        super(Semantic_flow, self).__init__()
        #inchannel为低分辨率图片通道数，outchannel为高分辨率图片通道数
        self.down_h=nn.Conv2d( inchannel, outchannel,1,bias=False)
        self.down_l=nn.Conv2d( outchannel, outchannel,1,bias=False)
        self.flow_make=nn.Conv2d( outchannel*2,2,kernel_size=3,padding=1,bias=False)
        #self.conv=nn.Conv2d(inchannel*2,outchannel,1)
    def forward(self,h_feature, low_feature):
        low_feature, h_feature =low_feature, h_feature  # low_feature 对应分辨率较高的特征图，h_feature即为低分辨率的high-level feature
        h_feature_orign = h_feature
        h, w = low_feature.size()[2:]
        size = (h, w)
        # 将high-level 和 low-level feature分别通过两个1x1卷积进行压缩
        low_feature = self.down_l(low_feature)
        h_feature = self.down_h(h_feature)
        # 将high-level feature进行双线性上采样
        h_feature = F.interpolate(h_feature, size=size, mode="bilinear", align_corners=False)
        # 预测语义流场 === 其实就是输入一个3x3的卷积
        flow = self.flow_make(torch.cat([h_feature, low_feature], 1))
        # 将Flow Field warp 到当前的 high-level feature中
        h_feature = self.flow_warp(h_feature_orign, flow, size=size)
        #h_feature=self.conv(h_feature)
        return h_feature

    @staticmethod
    def flow_warp(inputs, flow, size):
        out_h, out_w = size  # 对应高分辨率的low-level feature的特征图尺寸
        n, c, h, w = inputs.size()  # 对应低分辨率的high-level feature的4个输入维度


        norm = torch.tensor([[[[out_w, out_h]]]]).type_as(inputs).to(inputs.device)
        # 从-1到1等距离生成out_h个点，每一行重复out_w个点，最终生成(out_h, out_w)的像素点
        w = torch.linspace(-1.0, 1.0, out_h).view(-1, 1).repeat(1, out_w)
        # 生成w的转置矩阵
        h = torch.linspace(-1.0, 1.0, out_w).repeat(out_h, 1)
        # 展开后进行合并
        grid = torch.cat((h.unsqueeze(2), w.unsqueeze(2)), 2)
        grid = grid.repeat(n, 1, 1, 1).type_as(inputs).to(inputs.device)
        grid = grid + flow.permute(0, 2, 3, 1) / norm
        #print(grid.size())
        # grid指定由input空间维度归一化的采样像素位置，其大部分值应该在[ -1, 1]的范围内
        # 如x=-1,y=-1是input的左上角像素，x=1,y=1是input的右下角像素。
        # 具体可以参考《Spatial Transformer Networks》，下方参考文献[2]
        output = F.grid_sample(inputs, grid,align_corners=False)
        #print(output.size())
        return output


def _no_grad_trunc_normal_(tensor, mean, std, a, b):
    # Cut & paste from PyTorch official master until it's in a few official releases - RW
    # Method based on https://people.sc.fsu.edu/~jburkardt/presentations/truncated_normal.pdf
    def norm_cdf(x):
        # Computes standard normal cumulative distribution function
        return (1. + math.erf(x / math.sqrt(2.))) / 2.

    if (mean < a - 2 * std) or (mean > b + 2 * std):
        warnings.warn("mean is more than 2 std from [a, b] in nn.init.trunc_normal_. "
                      "The distribution of values may be incorrect.",
                      stacklevel=2)

    with torch.no_grad():
        # Values are generated by using a truncated uniform distribution and
        # then using the inverse CDF for the normal distribution.
        # Get upper and lower cdf values
        l = norm_cdf((a - mean) / std)
        u = norm_cdf((b - mean) / std)

        # Uniformly fill tensor with values from [l, u], then translate to
        # [2l-1, 2u-1].
        tensor.uniform_(2 * l - 1, 2 * u - 1)

        # Use inverse cdf transform for normal distribution to get truncated
        # standard normal
        tensor.erfinv_()

        # Transform to proper mean, std
        tensor.mul_(std * math.sqrt(2.))
        tensor.add_(mean)

        # Clamp to ensure it's in the proper range
        tensor.clamp_(min=a, max=b)
        return tensor


def trunc_normal_(tensor, mean=0., std=1., a=-2., b=2.):
    r"""
    Fills the input Tensor with values drawn from a truncated
    normal distribution. The values are effectively drawn from the
    normal distribution :math:`\mathcal{N}(\text{mean}, \text{std}^2)`
    with values outside :math:`[a, b]` redrawn until they are within
    the bounds. The method used for generating the random values works
    best when :math:`a \leq \text{mean} \leq b`.
    Args:
        tensor: an n-dimensional `torch.Tensor`
        mean: the mean of the normal distribution
        std: the standard deviation of the normal distribution
        a: the minimum cutoff value
        b: the maximum cutoff value
    Examples:
        >>> w = torch.empty(3, 5)
        >>> nn.init.trunc_normal_(w)
    """
    return _no_grad_trunc_normal_(tensor, mean, std, a, b)

class GELU(nn.Module):
    def __init__(self):
        super(GELU, self).__init__()

    def forward(self, x):
        return 0.5 * x * (1 + torch.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * torch.pow(x, 3))))


class OverlapPatchEmbed(nn.Module):
    def __init__(self, patch_size=7, stride=4, in_chans=3, embed_dim=768):
        super().__init__()
        patch_size = (patch_size, patch_size)
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride,
                              padding=(patch_size[0] // 2, patch_size[1] // 2))
        self.norm = nn.LayerNorm(embed_dim)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        x = self.proj(x)
        _, _, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)
        x = self.norm(x)

        return x, H, W

class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., sr_ratio=1):
        super().__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.q = nn.Linear(dim, dim, bias=qkv_bias)

        self.sr_ratio = sr_ratio
        if sr_ratio > 1:
            self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)
            self.norm = nn.LayerNorm(dim)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)

        self.attn_drop = nn.Dropout(attn_drop)

        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W):
        B, N, C = x.shape
        # bs, 16384, 32 => bs, 16384, 32 => bs, 16384, 8, 4 => bs, 8, 16384, 4
        q = self.q(x).reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        if self.sr_ratio > 1:
            # bs, 16384, 32 => bs, 32, 128, 128
            x_ = x.permute(0, 2, 1).reshape(B, C, H, W)
            # bs, 32, 128, 128 => bs, 32, 16, 16 => bs, 256, 32
            x_ = self.sr(x_).reshape(B, C, -1).permute(0, 2, 1)
            x_ = self.norm(x_)
            # bs, 256, 32 => bs, 256, 64 => bs, 256, 2, 8, 4 => 2, bs, 8, 256, 4
            kv = self.kv(x_).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        else:
            kv = self.kv(x).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        # bs, 8, 16384, 4 @ bs, 8, 4, 256 => bs, 8, 16384, 256
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        # bs, 8, 16384, 256  @ bs, 8, 256, 4 => bs, 8, 16384, 4 => bs, 16384, 32
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        # bs, 16384, 32 => bs, 16384, 32
        x = self.proj(x)
        x = self.proj_drop(x)

        return x


def drop_path(x, drop_prob: float = 0., training: bool = False, scale_by_keep: bool = True):
    """
    Drop paths (Stochastic Depth) per sample (when applied in main path of residual blocks).
    This is the same as the DropConnect impl I created for EfficientNet, etc networks, however,
    the original name is misleading as 'Drop Connect' is a different form of dropout in a separate paper...
    See discussion: https://github.com/tensorflow/tpu/issues/494#issuecomment-532968956 ... I've opted for
    changing the layer and argument names to 'drop path' rather than mix DropConnect as a layer name and use
    'survival rate' as the argument.
    """
    if drop_prob == 0. or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # work with diff dim tensors, not just 2D ConvNets
    random_tensor = x.new_empty(shape).bernoulli_(keep_prob)
    if keep_prob > 0.0 and scale_by_keep:
        random_tensor.div_(keep_prob)
    return x * random_tensor


class DropPath(nn.Module):
    def __init__(self, drop_prob=None, scale_by_keep=True):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob
        self.scale_by_keep = scale_by_keep

    def forward(self, x):
        return drop_path(x, self.drop_prob, self.training, self.scale_by_keep)


class DWConv(nn.Module):
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x, H, W):
        B, N, C = x.shape
        x = x.transpose(1, 2).view(B, C, H, W)
        x = self.dwconv(x)
        x = x.flatten(2).transpose(1, 2)

        return x


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.fc1 = nn.Linear(in_features, hidden_features)
        self.dwconv = DWConv(hidden_features)
        self.act = act_layer()

        self.fc2 = nn.Linear(hidden_features, out_features)

        self.drop = nn.Dropout(drop)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W):
        x = self.fc1(x)
        x = self.dwconv(x, H, W)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class Block(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=GELU, norm_layer=nn.LayerNorm, sr_ratio=1):
        super().__init__()
        self.norm1 = norm_layer(dim)

        self.attn = Attention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
            attn_drop=attn_drop, proj_drop=drop, sr_ratio=sr_ratio
        )
        self.norm2 = norm_layer(dim)
        self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W):
        x = x + self.drop_path(self.attn(self.norm1(x), H, W))
        x = x + self.drop_path(self.mlp(self.norm2(x), H, W))
        return x

class MixVisionTransformer(nn.Module):
    def __init__(self, in_chans=3, num_classes=1000, embed_dims=[32, 64, 160, 256],
                 num_heads=[1, 2, 4, 8], mlp_ratios=[4, 4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[3, 4, 6, 3], sr_ratios=[8, 4, 2, 1]):
        super().__init__()
        self.num_classes = num_classes
        self.depths = depths

        # ----------------------------------#
        #   Transformer模块，共有四个部分
        # ----------------------------------#
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]

        # ----------------------------------#
        #   block1
        # ----------------------------------#
        # -----------------------------------------------#
        #   对输入图像进行分区，并下采样
        #   512, 512, 3 => 128, 128, 32 => 16384, 32
        # -----------------------------------------------#
        self.patch_embed1 = OverlapPatchEmbed(patch_size=7, stride=4, in_chans=in_chans, embed_dim=embed_dims[0])
        # -----------------------------------------------#
        #   利用transformer模块进行特征提取
        #   16384, 32 => 16384, 32
        # -----------------------------------------------#
        cur = 0
        self.block1 = nn.ModuleList(
            [
                Block(
                    dim=embed_dims[0], num_heads=num_heads[0], mlp_ratio=mlp_ratios[0], qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                    sr_ratio=sr_ratios[0]
                )
                for i in range(depths[0])
            ]
        )
        self.norm1 = norm_layer(embed_dims[0])

        # ----------------------------------#
        #   block2
        # ----------------------------------#
        # -----------------------------------------------#
        #   对输入图像进行分区，并下采样
        #   128, 128, 32 => 64, 64, 64 => 4096, 64
        # -----------------------------------------------#
        self.patch_embed2 = OverlapPatchEmbed(patch_size=3, stride=2, in_chans=embed_dims[0], embed_dim=embed_dims[1])
        # -----------------------------------------------#
        #   利用transformer模块进行特征提取
        #   4096, 64 => 4096, 64
        # -----------------------------------------------#
        cur += depths[0]
        self.block2 = nn.ModuleList(
            [
                Block(
                    dim=embed_dims[1], num_heads=num_heads[1], mlp_ratio=mlp_ratios[1], qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                    sr_ratio=sr_ratios[1]
                )
                for i in range(depths[1])
            ]
        )
        self.norm2 = norm_layer(embed_dims[1])

        # ----------------------------------#
        #   block3
        # ----------------------------------#
        # -----------------------------------------------#
        #   对输入图像进行分区，并下采样
        #   64, 64, 64 => 32, 32, 160 => 1024, 160
        # -----------------------------------------------#
        self.patch_embed3 = OverlapPatchEmbed(patch_size=3, stride=2, in_chans=embed_dims[1], embed_dim=embed_dims[2])
        # -----------------------------------------------#
        #   利用transformer模块进行特征提取
        #   1024, 160 => 1024, 160
        # -----------------------------------------------#
        cur += depths[1]
        self.block3 = nn.ModuleList(
            [
                Block(
                    dim=embed_dims[2], num_heads=num_heads[2], mlp_ratio=mlp_ratios[2], qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                    sr_ratio=sr_ratios[2]
                )
                for i in range(depths[2])
            ]
        )
        self.norm3 = norm_layer(embed_dims[2])

        # ----------------------------------#
        #   block4
        # ----------------------------------#
        # -----------------------------------------------#
        #   对输入图像进行分区，并下采样
        #   32, 32, 160 => 16, 16, 256 => 256, 256
        # -----------------------------------------------#
        self.patch_embed4 = OverlapPatchEmbed(patch_size=3, stride=2, in_chans=embed_dims[2], embed_dim=embed_dims[3])
        # -----------------------------------------------#
        #   利用transformer模块进行特征提取
        #   256, 256 => 256, 256
        # -----------------------------------------------#
        cur += depths[2]
        self.block4 = nn.ModuleList(
            [
                Block(
                    dim=embed_dims[3], num_heads=num_heads[3], mlp_ratio=mlp_ratios[3], qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + i], norm_layer=norm_layer,
                    sr_ratio=sr_ratios[3]
                )
                for i in range(depths[3])
            ]
        )
        self.norm4 = norm_layer(embed_dims[3])

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        B = x.shape[0]
        outs = []

        # ----------------------------------#
        #   block1
        # ----------------------------------#
        x, H, W = self.patch_embed1.forward(x)
        for i, blk in enumerate(self.block1):
            x = blk.forward(x, H, W)
        x = self.norm1(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        outs.append(x)

        # ----------------------------------#
        #   block2
        # ----------------------------------#
        x, H, W = self.patch_embed2.forward(x)
        for i, blk in enumerate(self.block2):
            x = blk.forward(x, H, W)
        x = self.norm2(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        outs.append(x)

        # ----------------------------------#
        #   block3
        # ----------------------------------#
        x, H, W = self.patch_embed3.forward(x)
        for i, blk in enumerate(self.block3):
            x = blk.forward(x, H, W)
        x = self.norm3(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        outs.append(x)

        # ----------------------------------#
        #   block4
        # ----------------------------------#
        x, H, W = self.patch_embed4.forward(x)
        for i, blk in enumerate(self.block4):
            x = blk.forward(x, H, W)
        x = self.norm4(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        outs.append(x)

        return outs

class mit_b0(MixVisionTransformer):
    def __init__(self, pretrained=False):
        super(mit_b0, self).__init__(
            embed_dims=[32, 64, 160, 256], num_heads=[1, 2, 5, 8], mlp_ratios=[4, 4, 4, 4],
            qkv_bias=True, norm_layer=partial(nn.LayerNorm, eps=1e-6), depths=[2, 2, 2, 2], sr_ratios=[8, 4, 2, 1],
            drop_rate=0.0, drop_path_rate=0.1)
        if pretrained:
            print("Load backbone weights")
            #self.load_state_dict(torch.load("model_data/segformer_b0_backbone_weights.pth"), strict=False)
            self.load_state_dict(torch.load(r"E:\code\ts\SEIFNet2\pretrain_model/b0_backbone_weights.pth"), strict=False)

class MLP(nn.Module):
    """
    Linear Embedding
    """

    def __init__(self, input_dim=2048, embed_dim=768):
        super().__init__()
        self.proj = nn.Linear(input_dim, embed_dim)

    def forward(self, x):
        x = x.flatten(2).transpose(1, 2)
        x = self.proj(x)
        return x


class ConvModule(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=0, g=1, act=True):
        super(ConvModule, self).__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2, eps=0.001, momentum=0.03)
        self.act = nn.ReLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def fuseforward(self, x):
        return self.act(self.conv(x))


class SegFormerHead_1(nn.Module):
    """
    SegFormer: Simple and Efficient Design for Semantic Segmentation with Transformers
    """

    def __init__(self, num_classes=20, in_channels=[32, 64, 160, 256], embedding_dim=768, dropout_ratio=0.1):
        super(SegFormerHead_1, self).__init__()
        c1_in_channels, c2_in_channels, c3_in_channels, c4_in_channels = in_channels

        self.linear_c4 = MLP(input_dim=c4_in_channels, embed_dim=embedding_dim)
        self.linear_c3 = MLP(input_dim=c3_in_channels, embed_dim=embedding_dim)
        self.linear_c2 = MLP(input_dim=c2_in_channels, embed_dim=embedding_dim)
        self.linear_c1 = MLP(input_dim=c1_in_channels, embed_dim=embedding_dim)

        self.linear_fuse = ConvModule(
            c1=embedding_dim * 4,
            c2=embedding_dim,
            k=1,
        )

        self.sef1 = Semantic_flow(256, 64)
        self.sef2 = Semantic_flow(256, 64)
        self.sef3 = Semantic_flow(256, 64)
        self.linear_pred = nn.Conv2d(embedding_dim, num_classes, kernel_size=1)
        self.dropout = nn.Dropout2d(dropout_ratio)

    def forward(self, inputs):
        c1, c2, c3, c4 = inputs
        #b0:torch.Size([8, 32, 64, 64]) torch.Size([8, 64, 32, 32]) torch.Size([8, 160, 16, 16]) torch.Size([8, 256, 8, 8])
        #print(c1.size(), c2.size(), c3.size(), c4.size())
        #b1 torch.Size([8, 64, 64, 64]) torch.Size([8, 128, 32, 32]) torch.Size([8, 320, 16, 16]) torch.Size([8, 512, 8, 8])
        ############## MLP decoder on C1-C4 ###########
        n, _, h, w = c4.shape

        _c4 = self.linear_c4(c4).permute(0, 2, 1).reshape(n, -1, c4.shape[2], c4.shape[3])
        #print(_c4.size())
        _c4_1 = self.sef1(_c4, c1)
        # print(_c4.size())
        _c4_2 = F.interpolate(_c4, size=c1.size()[2:], mode='bilinear', align_corners=False)
        # print(_c4.size())
        _c4 = _c4_1 + _c4_2

        _c3 = self.linear_c3(c3).permute(0, 2, 1).reshape(n, -1, c3.shape[2], c3.shape[3])

        _c3_1 = self.sef2(_c3, c1)
        _c3_2 = F.interpolate(_c3, size=c1.size()[2:], mode='bilinear', align_corners=False)
        # print(_c3.size())
        _c3 = _c3_1 + _c3_2

        _c2 = self.linear_c2(c2).permute(0, 2, 1).reshape(n, -1, c2.shape[2], c2.shape[3])
        _c2_1 = self.sef3(_c2, c1)
        _c2_2 = F.interpolate(_c2, size=c1.size()[2:], mode='bilinear', align_corners=False)
        _c2 = _c2_1 + _c2_2
        # print(_c2.size())

        _c1 = self.linear_c1(c1).permute(0, 2, 1).reshape(n, -1, c1.shape[2], c1.shape[3])

        _c = self.linear_fuse(torch.cat([_c4, _c3, _c2, _c1], dim=1))

        x = self.dropout(_c)
        x = self.linear_pred(x)
        #print(x.size())
        return x


class SegFormerHead_0(nn.Module):
    """
    SegFormer: Simple and Efficient Design for Semantic Segmentation with Transformers
    """

    def __init__(self, num_classes=20, in_channels=[32, 64, 160, 256], embedding_dim=768, dropout_ratio=0.1):
        super(SegFormerHead_0, self).__init__()
        c1_in_channels, c2_in_channels, c3_in_channels, c4_in_channels = in_channels

        self.linear_c4 = MLP(input_dim=c4_in_channels, embed_dim=embedding_dim)
        self.linear_c3 = MLP(input_dim=c3_in_channels, embed_dim=embedding_dim)
        self.linear_c2 = MLP(input_dim=c2_in_channels, embed_dim=embedding_dim)
        self.linear_c1 = MLP(input_dim=c1_in_channels, embed_dim=embedding_dim)

        self.linear_fuse = ConvModule(
            c1=embedding_dim * 4,
            c2=embedding_dim,
            k=1,
        )

        self.sef1 = Semantic_flow(256, 32)
        self.sef2 = Semantic_flow(256, 32)
        self.sef3 = Semantic_flow(256, 32)
        self.linear_pred = nn.Conv2d(embedding_dim, num_classes, kernel_size=1)
        self.dropout = nn.Dropout2d(dropout_ratio)

    def forward(self, inputs):
        c1, c2, c3, c4 = inputs
        # torch.Size([8, 32, 64, 64]) torch.Size([8, 64, 32, 32]) torch.Size([8, 160, 16, 16]) torch.Size([8, 256, 8, 8])
        # print(c1.size(), c2.size(), c3.size(), c4.size())
        ############## MLP decoder on C1-C4 ###########
        n, _, h, w = c4.shape

        _c4 = self.linear_c4(c4).permute(0, 2, 1).reshape(n, -1, c4.shape[2], c4.shape[3])
        _c4_1 = self.sef1(_c4, c1)
        #print(_c4.size())
        _c4_2 = F.interpolate(_c4, size=c1.size()[2:], mode='bilinear', align_corners=False)
        # print(_c4.size())
        _c4 = _c4_1 + _c4_2

        _c3 = self.linear_c3(c3).permute(0, 2, 1).reshape(n, -1, c3.shape[2], c3.shape[3])

        _c3_1 = self.sef2(_c3, c1)
        _c3_2 = F.interpolate(_c3, size=c1.size()[2:], mode='bilinear', align_corners=False)
        # print(_c3.size())
        _c3 = _c3_1 + _c3_2

        _c2 = self.linear_c2(c2).permute(0, 2, 1).reshape(n, -1, c2.shape[2], c2.shape[3])
        #print(_c2.size())
        _c2_1 = self.sef3(_c2, c1)
        _c2_2 = F.interpolate(_c2, size=c1.size()[2:], mode='bilinear', align_corners=False)
        _c2 = _c2_1 + _c2_2
        # print(_c2.size())

        _c1 = self.linear_c1(c1).permute(0, 2, 1).reshape(n, -1, c1.shape[2], c1.shape[3])

        _c = self.linear_fuse(torch.cat([_c4, _c3, _c2, _c1], dim=1))

        x = self.dropout(_c)
        x = self.linear_pred(x)
        # print(x.size())
        return x
class SFEARNet(nn.Module):
    def __init__(self, num_classes=21, phi='b1', pretrained=False):
        super(SFEARNet, self).__init__()
        self.in_channels = {
            # 'b0': [32, 64, 160, 256], 'b1': [64, 128, 320, 512], 'b2': [64, 128, 320, 512],
            # 'b3': [64, 128, 320, 512], 'b4': [64, 128, 320, 512], 'b5': [64, 128, 320, 512],
            'b0': [32, 64, 160, 256], 'b1': [64, 128, 320, 512],
        }[phi]
        self.backbone = {
            # 'b0': mit_b0, 'b1': mit_b1, 'b2': mit_b2,
            # 'b3': mit_b3, 'b4': mit_b4, 'b5': mit_b5,
            'b0': mit_b0 #'b1': mit_b1,
        }[phi](pretrained)
        self.embedding_dim = {
            # 'b0': 256, 'b1': 256, 'b2': 768,
            # 'b3': 768, 'b4': 768, 'b5': 768,
            'b0': 256, 'b1': 256,
        }[phi]



        if phi=='b1':
            self.decode_head = SegFormerHead_1(num_classes, self.in_channels, self.embedding_dim)
            self.re = Resampler(64, 256)
            self.re2 = Resampler(64, 256)
            self.eg = Edge_Guidance_1()
            self.py1 = Pyramid_Merge(64)
            self.py2 = Pyramid_Merge(128)
            self.py3 = Pyramid_Merge(320)
            self.py4 = Pyramid_Merge(512)
        elif phi=='b0':
            self.decode_head = SegFormerHead_0(num_classes, self.in_channels, self.embedding_dim)
            self.re = Resampler(64, 256)
            self.re2 = Resampler(64, 256)
            self.eg = Edge_Guidance_0()
            self.py1 = Pyramid_Merge(32)
            self.py2 = Pyramid_Merge(64)
            self.py3 = Pyramid_Merge(160)
            self.py4 = Pyramid_Merge(256)

    def forward(self, input1,input2):
        H, W = input1.size(2), input1.size(3)

        x1 = self.backbone(input1)
        x2 = self.backbone(input2)
        #x=[torch.abs(xa-xb) for xa,xb in zip(x1,x2)]
        x_0=self.py1(x1[0],x2[0])
        x_1 = self.py2(x1[1],x2[1])
        x_2 = self.py3(x1[2], x2[2])
        x_3 = self.py4(x1[3], x2[3])
        x=[x_0,x_1,x_2,x_3]
        #print(x_3.size())

        eg=self.eg(x)
        edge=eg[0]
        x=eg[1:]
        #print(x[0].size())
        x = self.decode_head(x)

        #x = F.interpolate(x, size=(H, W), mode='bilinear', align_corners=True)
        x=self.re(x)
        edge=self.re2(edge)
        return x,edge


if __name__ == '__main__':
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    input1 = torch.rand([8, 3, 256, 256]).to(device)
    input2 = torch.rand([8, 3, 256, 256]).to(device)
    model = SFEARNet(num_classes=2, phi='b0',pretrained=False).to(device)
    out = model(input1,input2)
    print(out[0].size())
    print(out[1].size())

    input_data1 = torch.randn([1, 3, 256, 256]).to(device)
    input_data2 = torch.randn([1, 3, 256, 256]).to(device)
    flops, params = profile(model, inputs=(input_data1,input_data2,))
    print('Number of parameters: ' + str(params))
    print('FLOPs: ' + str(flops))
    print(params / 10 ** 6)
    print(flops / 10 ** 9)
