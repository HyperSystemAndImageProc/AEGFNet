import torch
from torch import nn
from torch.nn import functional as F



import math
import einops

import warnings

def _trunc_normal_(tensor, mean, std, a, b):

    def norm_cdf(x):

        return (1. + math.erf(x / math.sqrt(2.))) / 2.

    if (mean < a - 2 * std) or (mean > b + 2 * std):
        warnings.warn("mean is more than 2 std from [a, b] in nn.init.trunc_normal_. "
                      "The distribution of values may be incorrect.",
                      stacklevel=2)
    l = norm_cdf((a - mean) / std)
    u = norm_cdf((b - mean) / std)
    tensor.uniform_(2 * l - 1, 2 * u - 1)
    tensor.erfinv_()
    tensor.mul_(std * math.sqrt(2.))
    tensor.add_(mean)

    tensor.clamp_(min=a, max=b)
    return tensor



class HFM(nn.Module):
    def __init__(self, c4_dims, factor=2):
        super(HFM, self).__init__()

        hidden_size = c4_dims//factor
        c4_size = c4_dims
        c3_size = c4_dims//(factor**1)
        c2_size = c4_dims//(factor**2)
        c1_size = c4_dims//(factor**3)

        self.conv1_4 = nn.Conv2d(c4_size+c3_size, hidden_size, 3, padding=1, bias=False)

        self.bn1_4 = nn.BatchNorm2d(hidden_size)
        self.relu1_4 = nn.ReLU()
        self.bn2_4 = nn.BatchNorm2d(hidden_size)
        self.relu2_4 = nn.ReLU()

        self.conv1_3 = nn.Conv2d(hidden_size + c2_size, hidden_size//factor, 3, padding=1, bias=False)
        self.bn1_3 = nn.BatchNorm2d(hidden_size//factor)
        self.relu1_3 = nn.ReLU()
        self.bn2_3 = nn.BatchNorm2d(hidden_size//factor)
        self.relu2_3 = nn.ReLU()

        self.conv1_2 = nn.Conv2d(hidden_size//factor + c1_size, hidden_size//(factor**2), 3, padding=1, bias=False)
        self.bn1_2 = nn.BatchNorm2d(hidden_size//(factor**2))
        self.relu1_2 = nn.ReLU()
        self.bn2_2 = nn.BatchNorm2d(hidden_size//(factor**2))
        self.relu2_2 = nn.ReLU()

        self.conv1_1 = nn.Conv2d(hidden_size//(factor**2), 2, 1)

    def forward(self, x_c4, x_c3, x_c2, x_c1):
        # fuse Y4 and Y3
        if x_c4.size(-2) < x_c3.size(-2) or x_c4.size(-1) < x_c3.size(-1):
            x_c4 = F.interpolate(input=x_c4, scale_factor=2, mode='bilinear', align_corners=True)
        x = torch.cat([x_c4, x_c3], dim=1)
        x = self.conv1_4(x)
        x = self.bn1_4(x)
        x = self.relu1_4(x)
        out3 = x

        # fuse top-down features and Y2 features
        if x.size(-2) < x_c2.size(-2) or x.size(-1) < x_c2.size(-1):
            x = F.interpolate(input=x, scale_factor=2, mode='bilinear', align_corners=True)
        x = torch.cat([x, x_c2], dim=1)
        x = self.conv1_3(x)
        x = self.bn1_3(x)
        x = self.relu1_3(x)
        out2 = x

        # fuse top-down features and Y1 features
        if x.size(-2) < x_c1.size(-2) or x.size(-1) < x_c1.size(-1):
            x = F.interpolate(input=x, scale_factor=2, mode='bilinear', align_corners=True)
        x = torch.cat([x, x_c1], dim=1)
        x = self.conv1_2(x)
        x = self.bn1_2(x)
        x = self.relu1_2(x)
        out1 = x

        return out3, out2, out1



def main():

    c4_dims = 256  # 假设特征图的通道数为256
    factor = 2  # 缩放因子


    model = HFM(c4_dims, factor)


    batch_size = 4
    c4_size = c4_dims
    c3_size = c4_dims // factor
    c2_size = c4_dims // (factor ** 2)
    c1_size = c4_dims // (factor ** 3)

    # 假设输入的图像尺寸是(4, c4_size, 32, 32)，这里的32是宽和高
    x_c4 = torch.randn(batch_size, c4_size, 32, 32)
    x_c3 = torch.randn(batch_size, c3_size, 64, 64)
    x_c2 = torch.randn(batch_size, c2_size, 128, 128)
    x_c1 = torch.randn(batch_size, c1_size, 256, 256)


    output = model(x_c4, x_c3, x_c2, x_c1)


    print(f"Output shape: {output.shape}")


if __name__ == '__main__':
    main()