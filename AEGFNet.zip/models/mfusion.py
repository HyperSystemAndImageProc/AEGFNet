import torch
import torch.nn as nn
from models.subnet.Attention import Attention
class MF(nn.Module):
    def __init__(self, in_d, out_d):
        super(MF, self).__init__()
        self.in_d = in_d
        self.out_d = out_d
        # self.chn = (in_d*2)//3


        self.conv_dr = nn.Sequential(
            nn.Conv2d(self.in_d, self.out_d, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(self.out_d),
            nn.ReLU(inplace=True)
        )

        self.conv_sub = nn.Sequential(
            nn.Conv2d(self.in_d, self.in_d, 3, padding=1, bias=False),
            nn.BatchNorm2d(self.in_d),
            nn.ReLU(inplace=True),
        )

        self.convmix = nn.Sequential(
            nn.Conv2d(2 * self.in_d, self.in_d, 3, groups=self.in_d, padding=1, bias=False),
            nn.BatchNorm2d(self.in_d),
            nn.ReLU(inplace=True),
        )

    def forward(self, x1, x2):


        b, c, h, w = x1.shape[0], x1.shape[1], x1.shape[2], x1.shape[3]

        x_f = torch.stack((x1, x2), dim=2)
        x_f = torch.reshape(x_f, (b, -1, h, w))
        x_f = self.convmix(x_f)
        out = self.conv_dr(x_f)

        return out


if __name__ == '__main__':
    x1 = torch.randn((32, 512, 8, 8))
    x2 = torch.randn((32, 512, 8, 8))
    model = TemporalFeatureInteractionModule(512, 64)
    out = model(x1, x2)
    print(out.shape)