import torch
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
from math import log
# from models.subnet.mhsa import Attention
from models.subnet.dwt import DWT_2D, IDWT_2D, DWTC, Conv3Relu
class Conv1x1(nn.Module):
    def __init__(self, inplanes, planes):
        super(Conv1x1, self).__init__()
        self.conv = nn.Conv2d(inplanes, planes, 1)
        self.bn = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

class ConvBNR(nn.Module):
    def __init__(self, inplanes, planes, kernel_size=3, stride=1, dilation=1, bias=False):
        super(ConvBNR, self).__init__()

        self.block = nn.Sequential(
            nn.Conv2d(inplanes, planes, kernel_size, stride=stride, padding=dilation, dilation=dilation, bias=bias),
            nn.BatchNorm2d(planes),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.block(x)
class EFF(nn.Module):
    def __init__(self):
        super(EFF, self).__init__()
        self.reduce1 = Conv1x1(96, 192)
        self.reduce4 = Conv1x1(768, 192)
        # self.att = Attention(768, attn_ratio=0.5, num_heads=768 // 64)
        self.attention = nn.Sequential(
            nn.Conv2d(768, 1, kernel_size=1),
            nn.Softmax(dim=1)
        )
        self.block = nn.Sequential(
            ConvBNR(768, 128, 3),
            # ConvBNR(256, 128, 3),
            nn.Conv2d(128, 1, 1)
        )
        self.dwt = DWT_2D(wave='haar')
        self.idwt = IDWT_2D(wave='haar')
        self.dwtc1 = DWTC(768)
        self.stage1dwt_Conv1 = Conv3Relu(1536, 768)

    def forward(self, x1, x4):
        x1 = self.reduce1(x1)
        x4 = F.interpolate(x4, size=(64, 64), mode='bilinear', align_corners=False)
        x4 = self.reduce4(x4)

        fa1dwt = self.dwt(x1)
        fa1dwt = self.dwtc1(fa1dwt)
        fb1dwt = self.dwt(x4)
        fb1dwt = self.dwtc1(fb1dwt)
        f1dwt = self.stage1dwt_Conv1(torch.cat([fa1dwt, fb1dwt], 1))
        f1idwt = self.idwt(f1dwt)
        x1_with_gradient = torch.cat((x1, f1idwt), dim=1)
        x4_with_gradient = torch.cat((x4, f1idwt), dim=1)
        attention_weights = self.attention(torch.cat((x4_with_gradient, x1_with_gradient), dim=1))
        x1_weighted = x1_with_gradient * attention_weights[:, :, :x1.size(2), :x1.size(3)]
        x4_weighted = x4_with_gradient * attention_weights[:, :, :x1.size(2), :x1.size(3)]
        out = torch.cat((x4_weighted, x1_weighted), dim=1)
        out = self.block(out)

        return out

    def compute_image_gradient(self, x):
        with torch.set_grad_enabled(True):
            x = torch.autograd.Variable(x, requires_grad=True)
            #x = x.clone().detach().requires_grad_()

            gradient_x = torch.autograd.grad(outputs=x.sum(), inputs=x, create_graph=True)[0]
            gradient_x = torch.abs(gradient_x)
            return gradient_x

class CAE(nn.Module):
    def __init__(self, in_channels, inter_channels=None, dimension=2, sub_sample=False, bn_layer=True):
        """
        :param in_channels:
        :param inter_channels:
        :param dimension:
        :param sub_sample:
        :param bn_layer:
        """
        super(CAE, self).__init__()
        assert dimension in [2, ]
        self.dimension = dimension
        self.sub_sample = sub_sample
        self.in_channels = in_channels
        self.inter_channels = inter_channels

        if self.inter_channels is None:
            self.inter_channels = in_channels // 2
            if self.inter_channels == 0:
                self.inter_channels = 1

        self.g1 = nn.Sequential(
            nn.BatchNorm2d(1),
            nn.Conv2d(in_channels=1, out_channels=self.inter_channels,
                      kernel_size=1, stride=1, padding=0)
        )
        self.g2 = nn.Sequential(
            nn.BatchNorm2d(self.in_channels),
            nn.Conv2d(in_channels=self.in_channels, out_channels=self.inter_channels,
                      kernel_size=1, stride=1, padding=0)
        )

        self.W1 = nn.Sequential(
            nn.Conv2d(9, out_channels=self.in_channels,
                      kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(self.in_channels)
        )
        self.W2 = nn.Sequential(
            nn.Conv2d(1024, out_channels=self.in_channels,
                      kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(self.in_channels)
        )
        self.theta1 = nn.Sequential(
            nn.BatchNorm2d(1),
            nn.Conv2d(in_channels=1, out_channels=self.inter_channels,
                      kernel_size=1, stride=1, padding=0),
        )
        self.theta2 = nn.Sequential(
            nn.BatchNorm2d(self.in_channels),
            nn.Conv2d(in_channels=self.in_channels, out_channels=self.inter_channels,
                      kernel_size=1, stride=1, padding=0),
        )
        self.phi1 = nn.Sequential(
            nn.BatchNorm2d(1),
            nn.Conv2d(in_channels=1, out_channels=self.inter_channels,
                      kernel_size=1, stride=1, padding=0),
        )
        self.phi2 = nn.Sequential(
            nn.BatchNorm2d(self.in_channels),
            nn.Conv2d(in_channels=self.in_channels, out_channels=self.inter_channels,
                      kernel_size=1, stride=1, padding=0),
        )
        self.energy_time_1_sf = nn.Softmax(dim=-1)
        self.energy_time_2_sf = nn.Softmax(dim=-1)
        self.energy_space_2s_sf = nn.Softmax(dim=-2)
        self.energy_space_1s_sf = nn.Softmax(dim=-2)

    def forward(self, x1, x2):
        """
        :param x: (b, c, h, w)
        :param return_nl_map: if True return z, nl_map, else only return z.
        :return:
        """
        if x1.size()[2:] != x2.size()[2:]:
          x1 = F.interpolate(x1, x2.size()[2:], mode='bilinear', align_corners=False)
        batch_size = x1.size(0)
        g_x11 = self.g1(x1).reshape(batch_size, self.inter_channels, -1)
        g_x21 = self.g2(x2).reshape(batch_size, self.inter_channels, -1)

        theta_x1 = self.theta1(x1).reshape(batch_size, self.inter_channels, -1)
        theta_x2 = theta_x1.permute(0, 2, 1)

        phi_x1 = self.phi2(x2).reshape(batch_size, self.inter_channels, -1)
        phi_x2 = phi_x1.permute(0, 2, 1)

        energy_time_1 = torch.matmul(theta_x1, phi_x2)
        energy_space_1 = torch.matmul(theta_x2, phi_x1)
        energy_time_1s = self.energy_time_1_sf(energy_time_1)
        energy_space_2s = self.energy_space_2s_sf(energy_space_1)

        y1 = energy_time_1s.reshape(batch_size, -1, *x2.size()[2:])
        y2 = energy_space_2s.reshape(batch_size, -1, *x1.size()[2:])
        out1 = x1 + self.W1(y1)
        out2 = x2 + self.W2(y2)
        out = out1 + out2
        return out
