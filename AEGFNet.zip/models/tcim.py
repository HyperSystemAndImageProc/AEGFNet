import torch
import torch.nn as nn
import torch.nn.functional as F


class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class Linear_BN(torch.nn.Sequential):
    def __init__(self, a, b, bn_weight_init=1):
        super().__init__()
        self.add_module('c', torch.nn.Linear(a, b, bias=False))
        bn = torch.nn.BatchNorm1d(b)
        torch.nn.init.constant_(bn.weight, bn_weight_init)
        torch.nn.init.constant_(bn.bias, 0)
        self.add_module('bn', bn)

    @torch.no_grad()
    def fuse(self):
        l, bn = self._modules.values()
        w = bn.weight / (bn.running_var + bn.eps)**0.5
        w = l.weight * w[:, None]
        b = bn.bias - bn.running_mean * bn.weight / \
            (bn.running_var + bn.eps) ** 0.5
        m = torch.nn.Linear(w.size(1), w.size(0))
        m.weight.data.copy_(w)
        m.bias.data.copy_(b)
        return m

    def forward(self, x):
        l, bn = self._modules.values()
        x = l(x)
        return bn(x.flatten(0, 1)).reshape_as(x)


class Residual(torch.nn.Module):
    def __init__(self, m):
        super().__init__()
        self.m = m

    def forward(self, x):
        return x + self.m(x)


class ScaleAwareGate(nn.Module):
    def __init__(self, inp, oup):
        super(ScaleAwareGate, self).__init__()

        self.local_embedding = nn.Conv2d(inp, oup, kernel_size=1)
        self.bn1 = nn.BatchNorm2d(oup)

        self.global_embedding = nn.Conv2d(inp, oup, kernel_size=1)
        self.bn2 = nn.BatchNorm2d(oup)

        self.global_act = nn.Conv2d(inp, oup, kernel_size=1)
        self.bn3 = nn.BatchNorm2d(oup)
        self.act = h_sigmoid()

    def forward(self, x_l, x_g):
        B, C, H, W = x_l.shape
        local_feat = self.local_embedding(x_l)
        local_feat = self.bn1(local_feat)

        global_feat = self.global_embedding(x_g)
        global_feat = self.bn2(global_feat)
        global_feat = F.interpolate(global_feat, size=(H, W), mode='bilinear', align_corners=False)

        global_act = self.global_act(x_g)
        global_act = self.bn3(global_act)
        sig_act = F.interpolate(self.act(global_act), size=(H, W), mode='bilinear', align_corners=False)

        out = local_feat * sig_act + global_feat
        return out


class Attention(torch.nn.Module):
    def __init__(self, dim, key_dim=32, num_heads=8, attn_ratio=2, activation=torch.nn.Hardswish):
        super().__init__()
        self.num_heads = num_heads
        self.scale = key_dim ** -0.5
        self.key_dim = key_dim
        self.nh_kd = nh_kd = key_dim * num_heads
        self.d = int(attn_ratio * key_dim)
        self.dh = int(attn_ratio * key_dim) * num_heads
        self.attn_ratio = attn_ratio
        h = self.dh + nh_kd * 2
        self.qkv = Linear_BN(dim, h)

        self.parallel_conv = nn.Sequential(
            nn.Hardswish(inplace=False),
            nn.Conv2d(self.dh, self.dh, kernel_size=3, padding=1, groups=self.dh),
        )
        self.to_out = nn.Linear(self.dh, dim)
        # self.proj = nn.Linear(1, 1)
        self.proj = nn.Linear(89, self.d)#修改为动态proj

    def forward(self, x, img_size):
        # x: [B, N, C]
        B, N, C = x.shape
        qkv = self.qkv(x)  # [B, N, h]
        q, k, v = qkv.view(B, N, self.num_heads, -1).split([self.key_dim, self.key_dim, self.d], dim=3)
        q = q.permute(0, 2, 1, 3)  # [B, num_heads, N, key_dim]
        k = k.permute(0, 2, 1, 3)  # [B, num_heads, N, key_dim]
        v = v.permute(0, 2, 1, 3)  # [B, num_heads, N, d]

        # 计算 img_shape 动态参数
        H, W = int(img_size ** 0.5), int(img_size ** 0.5)
        v0 = v[:, :, :H * W, :]  # 假设 H*W <= N

        v0 = v0.reshape(B, self.dh, H, W)
        v_conv = self.parallel_conv(v0).flatten(2)  # [B, dh, H*W]

        attn = (q @ k.transpose(-2, -1)) * self.scale  # [B, num_heads, N, N]
        attn = attn.softmax(dim=-1)
        x = (attn @ v).transpose(1, 2).reshape(B, -1, N)  # [B, dh, N]
        # x = self.proj(x.mean(dim=2, keepdim=True)) + v_conv  # 简化的proj
        x = self.proj(x) + v_conv
        x = self.to_out(x.permute(0, 2, 1))  # [B, N, dim]
        return x


class CrossScaleAttention(nn.Module):
    def __init__(self, dim, img_shape=120, att_shape=314):
        super().__init__()
        self.bn1 = nn.BatchNorm2d(dim)

        self.DWConv1 = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, stride=2, padding=1, groups=dim),
            nn.BatchNorm2d(dim),
        )
        self.DWConv2 = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=5, stride=3, padding=2, groups=dim),
            nn.BatchNorm2d(dim),
        )
        # self.attention = Attention(dim, img_shape, att_shape)
        self.attention = Attention(dim, key_dim=32, num_heads=8, attn_ratio=2)
        self.bn4 = nn.BatchNorm2d(dim)
        self.activate = nn.Hardswish()
        self.conv = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        xis = (x.shape[2])*(x.shape[3])
        x0 = self.bn1(x)
        x1 = self.DWConv1(x0)
        x2 = self.DWConv2(x0)
        # [B, C, H, W] -> [B, C, H*W]
        x0, x1, x2 = x0.view(x0.shape[0], x0.shape[1], -1), x1.view(x1.shape[0], x1.shape[1], -1), x2.view(x2.shape[0],
                                                                                                           x2.shape[1],
                                                                                                           -1)
        attn = torch.cat((x0, x1, x2), dim=2).permute(0, 2, 1)
        attn = self.attention(attn, img_size=xis)
        attn = attn.permute(0, 2, 1).contiguous().view(x0.shape[0], x0.shape[1], x.shape[2], x.shape[3])
        x = self.conv(self.activate(self.bn4(attn)))
        return x


class SSIM(nn.Module):
    def __init__(self, dim, channels, mlp_ratio=2):
        super().__init__()
        self.csa1 = Residual(CrossScaleAttention(dim))
        self.intra_ff = Residual(IntraFeedForward(channels, mlp_ratio))
        self.csa2 = Residual(CrossScaleAttention(dim))
        self.ff = Residual(FeedForward(dim, dim * mlp_ratio))

    def forward(self, x):
        x = self.csa1(x)
        x = self.intra_ff(x)
        x = self.csa2(x)
        x = self.ff(x)
        return x


class PyramidPoolAgg(nn.Module):
    def __init__(self, stride):
        super(PyramidPoolAgg, self).__init__()
        self.stride = stride

    def forward(self, inputs):
        """
        前向传播方法，替换自适应平均池化为确定性的平均池化实现。

        参数：
            inputs (list of Tensor): 输入张量列表，假设每个张量的形状为 (B, C, H, W)

        返回：
            Tensor: 在通道维度上拼接后的池化结果，形状为 (B, C_total, H_out, W_out)
        """
        # 获取最后一个输入张量的高度和宽度
        B, C, H_last, W_last = inputs[-1].shape

        # 计算目标输出尺寸
        H_out = (H_last - 1) // self.stride + 1
        W_out = (W_last - 1) // self.stride + 1

        # 对每个输入张量应用确定性的自适应平均池化
        pooled = [self.deterministic_adaptive_avg_pool2d(inp, (H_out, W_out)) for inp in inputs]

        # 在通道维度上进行拼接
        return torch.cat(pooled, dim=1)

    def deterministic_adaptive_avg_pool2d(self, x, output_size):
        """
        自定义的确定性自适应平均池化实现。

        参数：
            x (Tensor): 输入张量，形状为 (B, C, H_in, W_in)
            output_size (tuple): 目标输出尺寸 (H_out, W_out)

        返回：
            Tensor: 池化后的张量，形状为 (B, C, H_out, W_out)
        """
        H_in, W_in = x.shape[2], x.shape[3]
        H_out, W_out = output_size

        # 计算步幅和池化窗口大小
        stride_h = H_in // H_out
        stride_w = W_in // W_out

        # 计算池化窗口大小，确保覆盖整个输入
        kernel_h = H_in - (H_out - 1) * stride_h
        kernel_w = W_in - (W_out - 1) * stride_w

        # 计算必要的填充
        pad_h = max((stride_h * (H_out - 1) + kernel_h - H_in), 0)
        pad_w = max((stride_w * (W_out - 1) + kernel_w - W_in), 0)

        # 应用填充（使用反射填充以保持边缘信息）
        if pad_h > 0 or pad_w > 0:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode='reflect')

        # 执行平均池化
        pooled = F.avg_pool2d(x, kernel_size=(kernel_h, kernel_w), stride=(stride_h, stride_w), ceil_mode=False)

        return pooled


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim):
        super().__init__()
        self.bn1 = nn.BatchNorm2d(dim)
        self.conv1 = nn.Conv2d(dim, hidden_dim, 1)
        self.bn2 = nn.BatchNorm2d(hidden_dim)
        # self.conv2 = nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1, groups=dim)
        self.conv2 = nn.Conv2d(hidden_dim, hidden_dim, 3, padding=1, groups=hidden_dim)  # 设置 groups=hidden_dim

        self.relu = nn.ReLU6()
        self.conv3 = nn.Conv2d(hidden_dim, dim, 1)

    def forward(self, x):
        out = self.conv3(self.relu(self.conv2(self.bn2(self.conv1(self.bn1(x))))))
        return out


class IntraFeedForward(nn.Module):
    def __init__(self, channels, mlp_ratio=2):
        super().__init__()
        self.channels = [channels[i]//4 for i in range(len(channels))]

        self.ff1 = Residual(FeedForward(self.channels[0], mlp_ratio*self.channels[0]))
        self.ff2 = Residual(FeedForward(self.channels[1], mlp_ratio*self.channels[1]))
        self.ff3 = Residual(FeedForward(self.channels[2], mlp_ratio*self.channels[2]))
        self.ff4 = Residual(FeedForward(self.channels[3], mlp_ratio*self.channels[3]))

    def forward(self, x):
        x1, x2, x3, x4 = x.split(self.channels, dim=1)
        x1 = self.ff1(x1)
        x2 = self.ff2(x2)
        x3 = self.ff3(x3)
        x4 = self.ff4(x4)
        return torch.cat([x1, x2, x3, x4], dim=1)


class CIB(nn.Module):
    def __init__(self, dim, num_layers = 4, channels=[96, 192, 384, 768], downsample=1):
        super().__init__()
        self.hidden_dim = dim // 4
        self.channels = channels
        self.stride = downsample

        self.down_channel = nn.Conv2d(dim, self.hidden_dim, 1)
        self.up_channel = nn.Conv2d(self.hidden_dim, dim, 1)

        # downsample to h/32, w/32
        self.pool = PyramidPoolAgg(stride=self.stride)
        self.block = nn.ModuleList([
            SSIM(self.hidden_dim, channels, mlp_ratio=2)
            for _ in range(num_layers)
        ])
        self.bn = nn.BatchNorm2d(self.hidden_dim)
        self.fusion = nn.ModuleList([
            ScaleAwareGate(channels[i], channels[i])
            for i in range(len(channels))
        ])

    def forward(self, input):  # [B, C, H, W]
        out = self.pool(input)  # [B, sum(C_i), H_target, W_target]
        out = self.down_channel(out)  # [B, hidden_dim, H_target, W_target]
        for layer in self.block:
            out = layer(out)
        out = self.bn(out)
        out = self.up_channel(out)  # [B, sum(C_i), H_target, W_target]
        xx = out.split(self.channels, dim=1)  # list of [B, C_i, H_target, W_target]
        results = []
        for i in range(len(self.channels)):
            CIM_before = input[i]
            # 对齐空间尺寸
            H_before, W_before = CIM_before.shape[2], CIM_before.shape[3]
            if (xx[i].shape[2] != H_before) or (xx[i].shape[3] != W_before):
                xx_i_resized = F.interpolate(xx[i], size=(H_before, W_before), mode='bilinear', align_corners=False)
            else:
                xx_i_resized = xx[i]
            out_ = self.fusion[i](CIM_before, xx_i_resized)
            results.append(out_)
        return results


if __name__ == '__main__':


    # 示例2：不同输入尺寸
    channels_new = [96, 192, 384, 768]
    dim_new = sum(channels_new)  # 1440
    model_new = CIM(dim=dim_new, channels=channels_new, num_layers=4, downsample=1)
    x1_new = torch.randn(4, 96, 64, 64)
    x2_new = torch.randn(4, 192, 32, 32)
    x3_new = torch.randn(4, 384, 16, 16)
    x4_new = torch.randn(4, 768, 8, 8)
    x_new = tuple([x1_new, x2_new, x3_new, x4_new])
    y_new = model_new(x_new)
    for i, out in enumerate(y_new, 1):
        print(f"输出特征图新 {i}: {out.shape}")
