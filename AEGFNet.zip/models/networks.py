import random
import shutil
import warnings
import os
from datetime import datetime

import matplotlib
import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
from functools import partial
from torch.optim import lr_scheduler
import matplotlib.pyplot as plt
import numpy as np
import cv2
import functools
from einops import rearrange

from compare.FC_EF import Unet

from compare.SNUNet import SNUNet_ECAM
from compare.DTCDSCN import CDNet_model
from compare.ChangeFormer import ChangeFormerV6
from compare.A2Net import A2Net
from compare.DMINet import DMINet
from compare.IFNet import DSIFN
from compare.TFI_GR import TFI_GR
from compare.SEIFNet import SEIFNet
from compare.STADENet import BASE_Transformer
from compare.ISDANet import MY_NET
from compare.BIT import BIT

from . import resnet

from compare.MobileNet import mobilenet_v2
from compare.ChangeFormer import EncoderTransformer_v3
from models.CBAM import *
from models.convnext_encoder import convnext_encoder
from models.csib import CSIB


from models.tcim import CIB
from models.Drop import DropBlock
from models.aspp import ASPP4, Conv3Relu, Conv1Relu
from models.hfm import HFM

from models.subnet.EGB import EFF, CAE




class TwoLayerConv2d(nn.Sequential):
    def __init__(self, in_channels, out_channels, kernel_size=3):
        super().__init__(nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size,
                            padding=kernel_size // 2, stride=1, bias=False),
                         nn.BatchNorm2d(in_channels),
                         nn.ReLU(),
                         nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size,
                            padding=kernel_size // 2, stride=1)
                         )
#尺度变换
def resize(input,
           size=None,
           scale_factor=None,
           mode='nearest',
           align_corners=None,
           warning=True):
    if warning:
        if size is not None and align_corners:
            input_h, input_w = tuple(int(x) for x in input.shape[2:])
            output_h, output_w = tuple(int(x) for x in size)
            if output_h > input_h or output_w > output_h:
                if ((output_h > 1 and output_w > 1 and input_h > 1
                     and input_w > 1) and (output_h - 1) % (input_h - 1)
                        and (output_w - 1) % (input_w - 1)):
                    warnings.warn(
                        f'When align_corners={align_corners}, '
                        'the output would more aligned if '
                        f'input size {(input_h, input_w)} is `x+1` and '
                        f'out size {(output_h, output_w)} is `nx+1`')
    return F.interpolate(input, size, scale_factor, mode, align_corners)








class SupervisedAttentionModule(nn.Module):
    def __init__(self, mid_d):
        super(SupervisedAttentionModule, self).__init__()
        self.mid_d = mid_d

        self.cbam = CBAM(channel = self.mid_d)

        self.conv2 = nn.Sequential(
            nn.Conv2d(self.mid_d, self.mid_d, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(self.mid_d),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):

        context = self.cbam(x)

        x_out = self.conv2(context)

        return x_out


# Helper Functions
def get_scheduler(optimizer, args):

    if args.lr_policy == 'linear':
        def lambda_rule(epoch):
            lr_l = 1.0 - epoch / float(args.max_epochs + 1)
            return lr_l
        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif args.lr_policy == 'step':
        step_size = args.max_epochs//3
        # args.lr_decay_iters
        scheduler = lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=0.1)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', args.lr_policy)
    return scheduler


class Identity(nn.Module):
    def forward(self, x):
        return x


def get_norm_layer(norm_type='instance'):

    if norm_type == 'batch':
        norm_layer = functools.partial(nn.BatchNorm2d, affine=True, track_running_stats=True)
    elif norm_type == 'instance':
        norm_layer = functools.partial(nn.InstanceNorm2d, affine=False, track_running_stats=False)
    elif norm_type == 'none':
        norm_layer = lambda x: Identity()
    else:
        raise NotImplementedError('normalization layer [%s] is not found' % norm_type)
    return norm_layer


def init_weights(net, init_type='normal', init_gain=0.02):

    def init_func(m):  # define the initialization function
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if init_type == 'normal':
                init.normal_(m.weight.data, 0.0, init_gain)
            elif init_type == 'xavier':
                init.xavier_normal_(m.weight.data, gain=init_gain)
            elif init_type == 'kaiming':
                init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                init.orthogonal_(m.weight.data, gain=init_gain)
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
            if hasattr(m, 'bias') and m.bias is not None:
                init.constant_(m.bias.data, 0.0)
        elif classname.find('BatchNorm2d') != -1:  # BatchNorm Layer's weight is not a matrix; only normal distribution applies.
            init.normal_(m.weight.data, 1.0, init_gain)
            init.constant_(m.bias.data, 0.0)

    print('initialize network with %s' % init_type)
    net.apply(init_func)  # apply the initialization function <init_func>


def init_net(net, init_type='normal', init_gain=0.02, gpu_ids=[]):

    if len(gpu_ids) > 0:
        assert(torch.cuda.is_available())
        net.to(gpu_ids[0])
        if len(gpu_ids) > 1:
            net = torch.nn.DataParallel(net, gpu_ids)  # multi-GPUs
    init_weights(net, init_type, init_gain=init_gain)
    return net


def define_G(args, init_type='normal', init_gain=0.02, gpu_ids=[]):
    if args.net_G == 'FC_EF':
        net = Unet(input_nbr=3, label_nbr=2)

    elif args.net_G == 'SNUNet':
        net = SNUNet_ECAM(in_ch=3, out_ch=2)
    elif args.net_G == 'DTCDSCN':
        net = CDNet_model(in_channels=3)
    elif args.net_G == 'ChangeFormer':
        net = ChangeFormerV6(embed_dim=args.embed_dim)
    elif args.net_G == 'BIT':
        net = BIT(input_nc=3, output_nc=2)
    elif args.net_G == 'A2Net':
        net = A2Net(input_nc=3, output_nc=2)
    elif args.net_G == 'DMINet':
        net = DMINet(pretrained=True)
    elif args.net_G == 'TFI-GR':
        net = TFI_GR(input_nc=3, output_nc=2)
    elif args.net_G == 'SEIFNet':
        net = SEIFNet(input_nc=3, output_nc=2)
    elif args.net_G == 'STADENet':
        net = BASE_Transformer(input_nc=3, output_nc=2)
    elif args.net_G == 'ISDANet':
        net = MY_NET(2)


    # 新网络
    elif args.net_G == 'AEGFNet':
        net = AEGFNet(args, input_nc=3, output_nc=2)


    else:
        raise NotImplementedError('Generator model name [%s] is not recognized' % args.net_G)
    return init_net(net, init_type, init_gain, gpu_ids)



# main Functions

class Backbone(torch.nn.Module):
    def __init__(self, args, input_nc, output_nc,
                 resnet_stages_num=5,
                 output_sigmoid=False, if_upsample_2x=True):
        """
        In the constructor we instantiate two nn.Linear modules and assign them as
        member variables.
        """
        super(Backbone, self).__init__()


        self.upsamplex2 = nn.Upsample(scale_factor=2, mode='nearest')
        self.upsamplex4 = nn.Upsample(scale_factor=4, mode='bilinear',align_corners=True)

        self.classifier = TwoLayerConv2d(in_channels=32, out_channels=output_nc)

        self.if_upsample_2x = if_upsample_2x

        #
        self.output_sigmoid = output_sigmoid
        self.sigmoid = nn.Sigmoid()




    def forward_single0(self, x):

        x = self.backbone(x)

        x0, x1, x2, x3 = x
        if self.if_upsample_2x:
            x = self.upsamplex2(x2)
        else:
            x = x2
        # output layers
        x = self.conv_pred(x)
        return x

    #SEIFNet
    def forward_single(self, x):

        f= self.backbone(x)

        return f

    def forward_down(self,x):
        f = self.downsample(x)
        return f

class LRDU(nn.Module):
    def __init__(self,in_c,factor):
        super(LRDU,self).__init__()

        self.up_factor = factor
        self.factor1 = factor*factor//2
        self.factor2 = factor*factor
        self.up = nn.Sequential(
            nn.Conv2d(in_c, self.factor1*in_c, (1,7), padding=(0, 3), groups=in_c),
            nn.Conv2d(self.factor1*in_c, self.factor2*in_c, (7,1), padding=(3, 0), groups=in_c),
            nn.PixelShuffle(factor)
        )

    def forward(self,x):
        x = self.up(x)
        return x

class AEGFNet(Backbone):

    def __init__(self, args, input_nc, output_nc,
                 decoder_softmax=False, embed_dim=64,
                 Building_Bool=False):
        super(AEGFNet, self).__init__(args, input_nc, output_nc)

        self.stage_dims = [96, 192, 384, 768]
        self.output_nc=output_nc
        #self.backbone = resnet.resnet18(pretrained=True)
        self.backbone1 = convnext_encoder()

        self.diff1 = CSIB(self.stage_dims[0], self.stage_dims[0])
        self.diff2 = CSIB(self.stage_dims[1], self.stage_dims[1])
        self.diff3 = CSIB(self.stage_dims[2], self.stage_dims[2])
        self.diff4 = CSIB(self.stage_dims[3], self.stage_dims[3])

        self.cib = CIB(dim=sum(self.stage_dims), channels=self.stage_dims, num_layers=4, downsample=1)

        #decoder

        self.hfm = HFM(2*self.stage_dims[3])
        self.eff = EFF()
        self.cae = CAE(192)
        self.sjconv = nn.Conv2d(in_channels=384, out_channels=192, kernel_size=1)
        self.w1 = nn.Parameter(torch.tensor(0.1))

        self.sam_p4 = SupervisedAttentionModule(2*self.stage_dims[3])
        #self.sam_p4_1 = SupervisedAttentionModule(self.stage_dims[3])
        self.sam_p3 = SupervisedAttentionModule(2 * self.stage_dims[0])
        self.sam_p2 = SupervisedAttentionModule(2 * self.stage_dims[0])
        self.sam_p1 = SupervisedAttentionModule(2 * self.stage_dims[0])
#
        self.upsample2 = LRDU(2*self.stage_dims[1],2)
        self.upsample4 = LRDU(2*self.stage_dims[2],4)
        self.upsample4_1 = LRDU(self.stage_dims[1], 4)
        self.upsample8 = LRDU(2*self.stage_dims[3],8)

        self.conv4 = nn.Conv2d(2*self.stage_dims[3], 2*self.stage_dims[0], kernel_size=1)
        self.conv3 = nn.Conv2d(2*self.stage_dims[2], 2*self.stage_dims[0], kernel_size=1)
        self.conv2 = nn.Conv2d(2*self.stage_dims[1], 2*self.stage_dims[0], kernel_size=1)

        self.conv_final1 = nn.Conv2d(2*self.stage_dims[0], output_nc, kernel_size=1)

        rate, size, step = (0.15, 7, 30)
        self.drop = DropBlock(rate=rate, size=size, step=step)

        self.stage_Conv_after_up = Conv3Relu(self.stage_dims[0], self.stage_dims[0])
        self.stage2_Conv_after_up = Conv3Relu(self.stage_dims[1], self.stage_dims[0])
        self.stage3_Conv_after_up = Conv3Relu(self.stage_dims[2], self.stage_dims[1])
        self.stage4_Conv_after_up = Conv3Relu(self.stage_dims[3], self.stage_dims[2])

        self.stage_Conv2 = Conv1Relu(self.stage_dims[0], self.stage_dims[0])
        self.stage1_Conv2 = Conv3Relu(self.stage_dims[1], self.stage_dims[0])
        self.stage2_Conv2 = Conv3Relu(self.stage_dims[2], self.stage_dims[1])
        self.stage3_Conv2 = Conv3Relu(self.stage_dims[3], self.stage_dims[2])

        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.up2 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.up3 = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)

        self.aspp4 = ASPP4(self.stage_dims[3])

        self.p5_head = nn.Conv2d(2 * self.stage_dims[3], 2, 1)
        self.p4_head = nn.Conv2d(2 * self.stage_dims[2], 2, 1)
        self.p3_head = nn.Conv2d(2 * self.stage_dims[1], 2, 1)
        self.p2_head = nn.Conv2d(2 * self.stage_dims[0], 2, 1)


    def forward(self, x1, x2):

        #res18
        f1 = self.backbone1(x1)
        f2 = self.backbone1(x2)

        x1_0, x1_1, x1_2, x1_3 = f1
        x2_0, x2_1, x2_2, x2_3 = f2

        edge_feature1 = self.eff(f1[0], f1[3])
        edge_feature2 = self.eff(f2[0], f2[3])
        fc1 = F.interpolate(f1[2], size=(32, 32), mode='bilinear', align_corners=False)
        fc2 = F.interpolate(f2[2], size=(32, 32), mode='bilinear', align_corners=False)
        fc1 = self.sjconv(fc1)
        fc2 = self.sjconv(fc2)

        hq_features1 = f1[1] + fc1
        hq_features2 = f2[1] + fc2
        copy1 = self.cae(edge_feature1, hq_features1)
        copy2 = self.cae(edge_feature2, hq_features2)

        [x1_0,x1_1,x1_2,x1_3, x2_0,x2_1,x2_2,x2_3] = self.drop([x1_0,x1_1,x1_2,x1_3, x2_0,x2_1,x2_2,x2_3])  # dropblock

        x1s = [x1_0, x1_1, x1_2, x1_3]
        x2s = [x2_0, x2_1, x2_2, x2_3]

        o1s = self.cib(x1s)
        o2s = self.cib(x2s)

        c_x10, c_x11, c_x12, c_x13 = o1s
        c_x20, c_x21, c_x22, c_x23 = o2s

        d1_1 = self.diff1(x1_0, x2_0, c_x10, c_x20)
        d2_1 = self.diff2(x1_1, x2_1, c_x11, c_x21)
        d3_1 = self.diff3(x1_2, x2_2, c_x12, c_x22)
        d4_1 = self.diff4(x1_3, x2_3, c_x13, c_x23)

        x1_3 = self.aspp4(x1_3)
        x2_3 = self.aspp4(x2_3)

        change3_2 = self.stage4_Conv_after_up(self.up(x1_3))
        x1_2 = self.stage3_Conv2(torch.cat([x1_2, change3_2], 1))
        change3_2 = self.stage4_Conv_after_up(self.up(x2_3))
        x2_2 = self.stage3_Conv2(torch.cat([x2_2, change3_2], 1))

        change2_2 = self.stage3_Conv_after_up(self.up(x1_2))
        x1_1 = self.stage2_Conv2(torch.cat([x1_1, change2_2], 1))
        change2_2 = self.stage3_Conv_after_up(self.up(x2_2))
        x2_1 = self.stage2_Conv2(torch.cat([x2_1, change2_2], 1))

        change1_2 = self.stage2_Conv_after_up(self.up(x1_1))
        x1_0 = self.stage1_Conv2(torch.cat([x1_0, change1_2], 1))
        change1_2 = self.stage2_Conv_after_up(self.up(x2_1))
        x2_0 = self.stage1_Conv2(torch.cat([x2_0, change1_2], 1))

        d1_2 = torch.abs(x1_0-x2_0)
        d2_2 = torch.abs(x1_1-x2_1)
        d3_2 = torch.abs(x1_2-x2_2)
        d4_2 = torch.abs(x1_3-x2_3)

        copy = torch.abs(copy1 - copy2)
        copy = F.interpolate(copy, size=(64, 64), mode='bilinear', align_corners=False)


        d1 = torch.cat([d1_1, d1_2],1)
        d2 = torch.cat([d2_1, d2_2],1)
        d3 = torch.cat([d3_1, d3_2],1)
        d4 = torch.cat([d4_1, d4_2],1)

        p4 = self.sam_p4(d4)

        pred_p5 = self.p5_head(p4)
        sd_43, sd_32, sd_21 = self.hfm(p4, d3, d2, d1)

        pred_p4 = self.p4_head(sd_43)
        pred_p3 = self.p3_head(sd_32)
        pred_p2 = self.p2_head(sd_21)

        p4_up = self.upsample8(p4)
        p4_up = self.conv4(p4_up)

        p3_up = self.upsample4(sd_43)
        p3_up = self.conv3(p3_up)

        p2_up = self.upsample2(sd_32)
        p2_up = self.conv2(p2_up)

        [p1, p2_up, p3_up, p4_up] = self.drop([sd_21, p2_up, p3_up, p4_up])

        p= p1+p2_up+p3_up+p4_up

        p = p + self.w1 * copy

        p_up =self.upsample4_1(p)

        output = self.conv_final1(p_up)

        pred_p2 = F.interpolate(pred_p2, size=(256, 256), mode='bilinear', align_corners=False)
        pred_p3 = F.interpolate(pred_p3, size=(256, 256), mode='bilinear', align_corners=False)
        pred_p4 = F.interpolate(pred_p4, size=(256, 256), mode='bilinear', align_corners=False)
        pred_p5 = F.interpolate(pred_p5, size=(256, 256), mode='bilinear', align_corners=False)

        return output, pred_p2, pred_p3, pred_p4, pred_p5




