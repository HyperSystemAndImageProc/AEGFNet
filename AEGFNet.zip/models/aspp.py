import torch
from torch import nn
import torch.nn.functional as F

class Conv1Relu(nn.Module):  # 1*1卷积用来降维
    def __init__(self, in_ch, out_ch):
        super(Conv1Relu, self).__init__()
        self.extract = nn.Sequential(nn.Conv2d(in_ch, out_ch, (1, 1), bias=False),
                                     nn.BatchNorm2d(out_ch),
                                     nn.ReLU(inplace=True))

    def forward(self, x):
        x = self.extract(x)
        return x

class Conv3Relu(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super(Conv3Relu, self).__init__()
        self.extract = nn.Sequential(nn.Conv2d(in_ch, out_ch, (3, 3), padding=(1, 1),
                                               stride=(stride, stride), bias=False),
                                     nn.BatchNorm2d(out_ch),
                                     nn.ReLU(inplace=True))

    def forward(self, x):
        x = self.extract(x)
        return x

class ASPP4(nn.Module):
    def __init__(self, in_channels, atrous_rates=(2, 3, 5)):
        super(ASPP4, self).__init__()

        rate1, rate2, rate3 = tuple(atrous_rates)

        out_channels = int(in_channels / 2)

        self.b1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, (3, 3), padding=rate1, dilation=rate1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(True))
        self.b2 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, (3, 3), padding=rate2, dilation=rate2, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(True))
        self.b3 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, (3, 3), padding=rate3, dilation=rate3, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(True))
        # self.b4 = nn.Sequential(
        # nn.Conv2d(in_channels, out_channels, (3, 3), padding=rate3, dilation=rate4, bias=False),
        # nn.BatchNorm2d(out_channels),
        # nn.ReLU(True))

        # 全局平均池化
        self.gap = nn.Sequential(nn.AdaptiveAvgPool2d(1),
                                 nn.Conv2d(in_channels, out_channels, (1, 1), bias=False),
                                 nn.BatchNorm2d(out_channels),
                                 nn.ReLU(True))

        self.dim_reduction = Conv3Relu(out_channels * 5, in_channels)
        self.dim_reduction2 = Conv3Relu(out_channels * 2, in_channels)

    def forward(self, x):
        h, w = x.shape[-2:]

        feat1 = self.b1(x)
        feat2 = self.b2(feat1)
        feat3 = self.b3(feat2)

        # feat4 = F.interpolate(self.gap(x), (h, w), mode="bilinear", align_corners=True)

        out1 = self.dim_reduction(torch.cat((x, feat1, feat2, feat3), 1))
        # out = self.dim_reduction2(torch.cat((add3, out1), 1))

        return out1