import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision import utils
import torch.nn.functional as F
import data_config
from datasets.CD_dataset import CDDataset
import argparse

def get_loader(data_name, img_size=256, batch_size=8, split='test',
               is_train=False, dataset='CDDataset'):
    dataConfig = data_config.DataConfig().get_data_config(data_name)
    root_dir = dataConfig.root_dir
    label_transform = dataConfig.label_transform

    if dataset == 'CDDataset':
        data_set = CDDataset(root_dir=root_dir, split=split,
                                 img_size=img_size, is_train=is_train,
                                 label_transform=label_transform)
    else:
        raise NotImplementedError(
            'Wrong dataset name %s (choose one from [CDDataset])'
            % dataset)

    shuffle = is_train
    dataloader = DataLoader(data_set, batch_size=batch_size,
                                 shuffle=shuffle, num_workers=4)


    return dataloader


def get_loaders(args):

    data_name = args.data_name
    dataConfig = data_config.DataConfig().get_data_config(data_name)
    root_dir = dataConfig.root_dir
    label_transform = dataConfig.label_transform
    split = args.split
    split_val = 'val'
    if hasattr(args, 'split_val'):
        split_val = args.split_val
    if args.dataset == 'CDDataset':
        training_set = CDDataset(root_dir=root_dir, split=split,
                                 img_size=args.img_size,is_train=True,
                                 label_transform=label_transform)
        val_set = CDDataset(root_dir=root_dir, split=split_val,
                                 img_size=args.img_size,is_train=False,
                                 label_transform=label_transform)
    else:
        raise NotImplementedError(
            'Wrong dataset name %s (choose one from [CDDataset,])'
            % args.dataset)

    datasets = {'train': training_set, 'val': val_set}
    dataloaders = {x: DataLoader(datasets[x], batch_size=args.batch_size,
                                 shuffle=True, num_workers=args.num_workers)
                   for x in ['train', 'val']}

    return dataloaders


def make_numpy_grid(tensor_data, pad_value=0,padding=0):
    tensor_data = tensor_data.detach()
    vis = utils.make_grid(tensor_data, pad_value=pad_value,padding=padding)
    vis = np.array(vis.cpu()).transpose((1,2,0))
    if vis.shape[2] == 1:
        vis = np.stack([vis, vis, vis], axis=-1)
    return vis


def de_norm(tensor_data):
    return tensor_data * 0.5 + 0.5


def get_device(args):
    # set gpu ids
    str_ids = args.gpu_ids.split(',')
    args.gpu_ids = []
    for str_id in str_ids:
        id = int(str_id)
        if id >= 0:
            args.gpu_ids.append(id)
    if len(args.gpu_ids) > 0:
        torch.cuda.set_device(args.gpu_ids[0])

def str2bool(v):
    if v.lower() in ['true', 1]:
        return True
    elif v.lower() in ['false', 0]:
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


def downsample_label_vectorized(label, new_size):
    batch_size, height, width = label.shape
    new_height, new_width = new_size

    stride_h = height // new_height
    stride_w = width // new_width

    # 重塑张量形状，将块分组
    label_reshaped = label.view(batch_size, new_height, stride_h, new_width, stride_w)

    # 统计每个块内的1的数量
    count_ones = label_reshaped.sum(dim=[2, 4])
    count_zeros = stride_h * stride_w - count_ones

    # 多数投票并转换为浮点数
    downsampled_label = (count_ones >= count_zeros).float()

    return downsampled_label

def downsample_multiclass_label(label, new_size):
    """
    使用多数投票下采样多类别标签。

    参数:
        label (torch.Tensor): 形状为 (batch_size, height, width) 的张量，包含整数类别标签 [0, num_classes-1]。
        new_size (tuple): (new_height, new_width)。
        num_classes (int): 类别数量。

    返回:
        torch.Tensor: 下采样后的标签，形状为 (batch_size, new_height, new_width)。
    """
    batch_size, num_classes, height, width = label.shape
    new_height, new_width = new_size

    stride_h = height // new_height
    stride_w = width // new_width

    # 对标签进行独热编码
    label_one_hot = F.one_hot(label, num_classes=num_classes)  # 形状: (batch_size, height, width, num_classes)
    label_one_hot = label_one_hot.permute(0, 3, 1, 2).float()  # 形状: (batch_size, num_classes, height, width)

    # 重新调整形状以分块
    label_reshaped = label_one_hot.unfold(2, stride_h, stride_h).unfold(3, stride_w, stride_w)
    label_reshaped = label_reshaped.contiguous().view(batch_size, num_classes, new_height, new_width, stride_h * stride_w)

    # 对块内的像素进行求和
    count = label_reshaped.sum(dim=-1)  # 形状: (batch_size, num_classes, new_height, new_width)

    # 选择出现次数最多的类别
    downsampled_label = count.argmax(dim=1).float()

    return downsampled_label
