# def saveMetricsPlot(metrics, plot_metrics, stage):
#     stage_name = list(metrics.keys())
#     stage_name.sort()
#     epochs = len(list(metrics.values())[0])
#
#     #draw plot
#     x = range(epochs)
#     len_stage = 1
#     len_metric = len(plot_metrics)
#     fig, axs = plt.subplots(len_metric, len_stage, dpi=600, figsize=(10,10))#
#     for index, each_subplot in enumerate(plot_metrics):
#         if each_subplot == "Loss":
#             axs[index].set_ylim(0, 0.1)
#         else:
#             axs[index].set_ylim(0, 100)
#         color = ['b','r','g','c','m','y','k','w']
#         for each_stage in stage:
#             axs[index].plot(x, metrics[each_subplot + " " + each_stage], label=each_stage)
#         axs[index].set_title(each_subplot)
#         axs[index].legend()
#     fig.savefig(save_dir + os.sep + "results.png", bbox_inches="tight")
# plt.close("all")
#
# def creatPlotProcess(metric_record,plot_metrics,stage):
#     plotProcess = Process(target=saveMetricsPlot, args=(metric_record,plot_metrics,stage))
#     plotProcess.start()
#     plotProcess.join()

import matplotlib.pyplot as plt


class ModelTrainer:
    def __init__(self, model, train_loader, optimizer, criterion):
        self.model = model
        self.train_loader = train_loader
        self.optimizer = optimizer
        self.criterion = criterion
        self.losses = []  # 用于记录每个 epoch 的损失值

    def train(self, num_epochs):
        for epoch in range(num_epochs):
            epoch_loss = 0.0
            for inputs, labels in self.train_loader:
                # 清除梯度
                self.optimizer.zero_grad()

                # 前向传播
                outputs = self.model(inputs)

                # 计算损失
                loss = self.criterion(outputs, labels)

                # 反向传播
                loss.backward()

                # 更新参数
                self.optimizer.step()

                # 累加损失
                epoch_loss += loss.item()

            # 记录每个 epoch 的平均损失
            avg_loss = epoch_loss / len(self.train_loader)
            self.losses.append(avg_loss)

            # 打印当前 epoch 的损失
            print(f'Epoch {epoch + 1}/{num_epochs}, Loss: {avg_loss:.4f}')

            # 绘制损失曲线（每个 epoch 后绘制一次）
            self.plot_loss()

    def plot_loss(self):
        plt.figure(figsize=(8, 6))
        plt.plot(range(1, len(self.losses) + 1), self.losses, label='Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title('Training Loss Curve')
        plt.grid(True)
        plt.legend()
        plt.show()


# 假设已经定义好了 model、train_loader、optimizer 和 criterion
trainer = ModelTrainer(model, train_loader, optimizer, criterion)
trainer.train(num_epochs=10)

